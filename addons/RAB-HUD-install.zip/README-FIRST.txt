RAB - put your personal line on the right

START HERE: RAB-HUD-Install.cmd   (build 1.2.0, about 26 KB)

  One file. Nothing else needed. Copy it to the PC you play on and
  double-click it. It carries the resource pack inside itself, so no
  .mcpack has to be imported and no file association can get in the way
  (a .mcpack is a ZIP - on a PC with WinRAR it can open in WinRAR instead
  of importing into Minecraft, which is why nothing happens sometimes).

  It prints what it does, step by step:

      1. makes sure Minecraft is closed
      2. finds your Minecraft data folder(s)
      3. installs the pack into resource_packs\RAB-Personal-HUD
      4. switches it on for every world that runs the RAB scoreboard
      5. reports what Minecraft will actually see, per data folder

  Step 5 is the one to read if the line has not moved. It prints, for
  each folder: whether the pack's manifest parses there, the worlds that
  reference it, and whether .mcpack / .mcaddon would import on a
  double-click or open in WinRAR instead.

  "worlds applied : 0" is not a failure. A world that already has the
  pack needs no change, and it says so: "already had it : 2".

  Then load the world and look at the BOTTOM-RIGHT corner.
  You should see:  yourname - OWNER - Rank


THEN, IF IT IS STILL ABOVE THE HOTBAR

  Local world - the pack is installed but that world has not switched it on:

      Play -> pencil (Edit) next to the world -> Settings
           -> Resource Packs -> Active -> add "RAB Personal HUD" -> Play

  Realm - a Realm serves its OWN pack list. Nothing installed on this PC
  changes it, and the pack can look active on the local copy while the
  Realm still runs without it. Either:

      Settings -> Global Resources -> activate "RAB Personal HUD"
          (this device only, no upload)

      or Realm settings -> download a backup -> apply BOTH packs to that
      local save -> Realm settings -> Replace World.
      RAB-Addon.mcaddon is both packs in one import, so the upload cannot
      drop the scoreboard. Replace World overwrites the live Realm, so
      take the backup first.


THE OTHER FILES

  RAB-Update.cmd    Installs the RAB scoreboard itself and keeps your
                    worlds bound to it. It also picks up RAB-HUD.mcpack
                    if that file sits next to it or in Downloads.
  RAB-Report.cmd    Prints what is installed on this PC and which worlds
                    have it, then changes nothing.
  RAB-HUD.mcpack    The pack on its own, for double-clicking in a world
                    whose Resource Packs list you want to edit by hand.
  RAB-Addon.mcaddon Scoreboard + HUD in one import, for uploading a world
                    to a Realm.


WHY THE SIDEBAR CANNOT DO THIS

  A scoreboard objective is bound to a display slot for the whole world.
  There is no per-player display in the API, so every player sees the same
  sidebar rows. The action bar is the one HUD surface the game draws per
  player - that is where the personal line lives, and this pack is what
  moves it to the right corner.
